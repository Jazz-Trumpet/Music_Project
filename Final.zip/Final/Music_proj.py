import string

class Music:


    
    def __init__(self, tone):
        """
        Parameter
        ----------
        tone: string
            the music key that the user inputs
        """ 
        # takes in a tone to be used by modules
        self.tone = tone
    #    
    def Enharmonics(self):
        """
        This module will determine which chromatic scale to use.
        either it uses all flats or all sharps, depending on which enharmonic is more useful.
        Add two numbers together. 
    
        Parameters
        ----------
        Flat_true : list
            defines which enharmonic to use for a given key
        is_flat : bool
            initialized as True and is used to determine if we should pass tone to Sharps() or Flats()
            
    
        Returns
        -------
        is_flat : bool
            Determines which enharmonic scale to use 
   
        
        """
        Flat_true = ['C','F','Bb','Eb','Ab','Db','Gb']
        is_flat = True
        if self.tone in Flat_true:
            is_flat = True
        if self.tone not in Flat_true:
            is_flat = False
        return is_flat
            
        

    def Sharps(self):
       
        """
        This module will take in a user inputed Tone,
        returning a list of 12 keys starting from that tone.
        This module will only return the sharp enharmonics
        
        Parameters
        ----------
        Chrom : list
            the notes in the sharp enharmonic scale
        End: bool
            stops the loop from itterating further
            
        Returns
        -------
        Sharp_tones: string
            String to be passed into class Modes()
        """
        
        chrom = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B','C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
        #initialize output list
        Sharp_tones = [] 
        #boolean to determine if at the last
        End = False     
        
        
        for item in chrom:
           # stop when we have enough notes
            if len(Sharp_tones) == 12:
                    End = True
            if End == True:
                break
            #append the first item equal to the input
            if item == self.tone: 
                Sharp_tones.append(self.tone) 
            #append the next items after the first one is defines    
            if item != self.tone and len(Sharp_tones) > 0:
                Sharp_tones.append(item)
            
            
                  
        return Sharp_tones
    
    
    def Flats(self):
        
        """
        This module will take in a user inputed Tone,
        returning a list of 12 keys starting from that tone.
        This module will only return the flat enharmonics
        
        Parameters
        ----------
        Chrom : list
            the notes in the sharp enharmonic scale
        End: bool
            stops the loop from itterating further
            
        Returns
        -------
        Flat_tones: string
            String to be passed into class Modes()
        """
        chrom = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B','C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B']
        #initialize output list
        Flat_tones = [] 
        #boolean to determine if at the last
        End = False     
        
        
        for item in chrom:
           # stop when we have enough notes
            if len(Flat_tones) == 12:
                    End = True
            if End == True:
                break
           #append the first item equal to the input
            if item == self.tone: 
                Flat_tones.append(self.tone)  
            #append the next items after the first one is defines
            if item != self.tone and len(Flat_tones) > 0:
                Flat_tones.append(item)
            
            
                  
        return Flat_tones
    
    
class Modes(Music):
    
    
    def __init__(self, tone, Chrom = []):
        """
        This module will decide which enharmonic to use
        
        Parameters
        ----------
        Input: list
            initiated to append a list of chromatic notes
        tone: string
            inherited from class Music()
            
        
        
        """
        super().__init__(tone)
        Input = Music(tone)
        #will 
        is_flat = Input.Enharmonics()
        if is_flat == True:
            self.Chrom = Input.Flats()
        if is_flat == False:
            self.Chrom = Input.Sharps()
     
    
    
    def Ionian(self):
        """
        This module defines what it means to be an Ionian mode
        
        Parameters
        ----------
        Ionian_mode: list
            initiated to append the notes of an ionian mode
        self.Chrom: list
            the chromatic scale that is manupulated by this module
            
         Return
         ----------
         Ionian_mode:
             the ionian mode based off of self.Chrom
            
        """
        Ionian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:6:2]:
                Ionian_mode.append(item)
            elif item in self.Chrom[5::2]:
                Ionian_mode.append(item)
        
        
        return Ionian_mode
    
    def Dorian(self):
        
        """
        This module defines what it means to be an Dorian mode
        
        Parameters
        ----------
        Dorian_mode: list
            initiated to append the notes of an dorian mode
        self.Chrom: list
            the chromatic scale that is manupulated by this module
            
         Return
         ----------
         Dorian_mode:
             the dorian mode based off of self.Chrom
            
        """
        
        Dorian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:3:2]:
                Dorian_mode.append(item)
            elif item == self.Chrom[3]:
                Dorian_mode.append(item)
            elif item in self.Chrom[5:10:2]:
                Dorian_mode.append(item)
            elif item == self.Chrom[10]:
                Dorian_mode.append(item)
        
        return Dorian_mode
    


    def Phrygian(self):
        
        """
        This module defines what it means to be an Phrygian mode
        
        Parameters
        ----------
        Phrygian_mode: list
            initiated to append the notes of an Phrygian mode
        self.Chrom: list
            the chromatic scale that is manupulated by this module
            
         Return
         ----------
         Phrygian_mode:
             the Phrygian mode based off of self.Chrom
            
        """
        
        Phrygian_mode = []
        
        for item in self.Chrom:
            if item in self.Chrom[0:2:]:
                Phrygian_mode.append(item)
            elif item in self.Chrom[3:8:2]:
                Phrygian_mode.append(item)
            elif item in self.Chrom[8:11:2]:
                Phrygian_mode.append(item)
           
    
        return Phrygian_mode
    
    def Lydian(self):
        
         """
        This module defines what it means to be an Lydian mode
        
        Parameters
        ----------
        Lydian_mode: list
            initiated to append the notes of an Lydian mode
        self.Chrom: list
            the chromatic scale that is manupulated by this module
            
         Return
         ----------
         Lydian_mode:
             the Lydian mode based off of self.Chrom
            
        """
        Lydian_mode = []
        
        for item in self.Chrom:
            if item in self.Chrom[0:7:2]:
                Lydian_mode.append(item)
            elif item in self.Chrom[7:12:2]:
                Lydian_mode.append(item)
            
                                     
        return Lydian_mode
    
    def Mixolydian(self):
        
         """
        This module defines what it means to be an Mixolydian mode
        
        Parameters
        ----------
        Mixolydian_mode: list
            initiated to append the notes of an Mixolydian mode
        self.Chrom: list
            the chromatic scale that is manupulated by this module
            
         Return
         ----------
         Mixolydian_mode:
             the Mixolydian mode based off of self.Chrom
            
        """
        Mixolydian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:5:2]:
                Mixolydian_mode.append(item)
            elif item in self.Chrom[5:10:2]:
                Mixolydian_mode.append(item)
            elif item == self.Chrom[10]:
                Mixolydian_mode.append(item)
        
        return Mixolydian_mode
    
    
    def Aeolian(self):
        
          """
        This module defines what it means to be an Aeolian mode
        
        Parameters
        ----------
        Aeolian_mode: list
            initiated to append the notes of an Aeolian mode
        self.Chrom: list
            the chromatic scale that is manupulated by this module
            
         Return
         ----------
         Aeolian_mode:
             the Aeolian mode based off of self.Chrom
            
        """
        Aeolian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:3:2]:
                Aeolian_mode.append(item)
            elif item == self.Chrom[3]:
                Aeolian_mode.append(item)
            elif item in self.Chrom[5:9:2]:
                Aeolian_mode.append(item)
            elif item in self.Chrom[8:11:2]:
                Aeolian_mode.append(item)
        
        return Aeolian_mode
    
    
    def Locrian(self):
        
           """
        This module defines what it means to be an Locrian mode
        
        Parameters
        ----------
        Locrian_mode: list
            initiated to append the notes of an Locrian mode
        self.Chrom: list
            the chromatic scale that is manupulated by this module
            
         Return
         ----------
         Locrian_mode:
             the Locrian mode based off of self.Chrom
            
        """
        
        Locrian_mode = []
        
        for item in self.Chrom:
            if item in self.Chrom[0:2:]:
                Locrian_mode.append(item)
            elif item in self.Chrom[3:6:2]:
                Locrian_mode.append(item)
            elif item == self.Chrom[6]:
                Locrian_mode.append(item)
            elif item in self.Chrom[8:11:2]:
                Locrian_mode.append(item)
           
    
        return Locrian_mode
    

