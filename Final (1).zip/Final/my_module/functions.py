from Music_proj import Music, Modes
import string

#from the chatbot assignment, will return a boolean to determine if Music_Bot shold terminate
def end_chat(input_list):
    
    if 'quit' in input_list:
        output = True
    else:
        output = False
    
    return output
#from the chatbot assignment, removes punctuation from the input_string 
def remove_punctuation(input_string):
    
    out_string = ''
    for char in input_string:
        # so that this function does not remove '#' from the music note
        if char == '#':
            out_string += char
        elif char not in string.punctuation:
            out_string += char
        else:
            continue
            
    return out_string
#from the chatbot assignment, removes punctuation and splits input into a list
def prepare_text(input_string):
    
    
    temp_string = input_string
    t = remove_punctuation(temp_string)
    out_list = t.split()
    
    return out_list
#from the chatbot assignment, combines strings
def string_concatenator(string1,string2,separator):
    output = (string1 + separator) + string2 
    
    return output
#from the chatbot assignment, combines lists to be sstrings
def list_to_string(input_list,separator):
    
    output = input_list[0]
    for item in input_list[1:]:
        output = string_concatenator(output,item,separator)
    
    
    return output

#The possible conventional keys 
MUSIC = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B','C#','D#','F#','G#','A#',]
#the possible modes of a major scale
MODES_IN = ['ionian', 'dorian', 'phrygian', 'lydian', 'mixolydian', 'aeolian','locrian']


def call_mode(tone,mode):
    """Add two numbers together. 
    
    Parameters
    ----------
    Input : passes char (tone) to Modes class for later manipulation
         
    output : intitialized as a list
        
    
    Returns
    -------
    output : list
        a mode of a key will be appended to this list. 
    """
    Input = Modes(tone)
    output = []
    #append ionian mode
    if mode == 'ionian':
        output.append(Input.Ionian())
    #append dorian mode
    elif mode == 'dorian':
        output.append(Input.Dorian())
    #append phrygian mode
    elif mode == 'phrygian':
        output.append(Input.Phrygian())
    #append lydian mode
    elif mode == 'lydian':
        output.append(Input.Lydian())
    #append mixolydian mode
    elif mode == 'mixolydian':
        output.append(Input.Mixolydian())
    #append aeolian mode
    elif mode == 'aeolian':
        output.append(Input.Aeolian())
    #append locrian mode
    elif mode == 'locrian':
        output.append(Input.Locrian())
    return output
        
        
#catchall for weird answers
UNKNOWN = ["I didn't quite get that, what key are we in? Whats the mode?"]

def is_in_list(list_one, list_two):
    """Check if any element of list_one is in list_two."""
    
    for element in list_one:
        if element in list_two:
            return True
    return False

def find_in_list(list_one, list_two):
    """Find and return an element from list_one that is in list_two, or None otherwise."""
    
    for element in list_one:
        if element in list_two:
            return element
    return None

#code adapted from chatbot assignment
def Music_Bot():
    """Main function to run our chatbot."""
    
    print('I am MusicBot. Ask me for a key and a mode.\nMake sure to capitalize the key, but leave the mode uncapitalized.\nType *quit* to end ')
    chat = True
    while chat:

        # Get a message from the user
        msg = input('INPUT :\t')
        out_msg = None

        # Check if the input is a question
        

        # Prepare the input message
        msg = prepare_text(msg)

        # Check for an end msg 
        if end_chat(msg):
            out_msg = 'Bye!'
            chat = False
           
        if not out_msg:

            # Initialize to collect a list of possible outputs
            outs = []
            #check if the user inputed a standard music key
            if is_in_list(msg, MUSIC):
                # calls find in list to return the appropriate music note
                tone = find_in_list(msg, MUSIC)
                #append to the out message
                outs.append(tone)
            
            
            # check if the user inputed a mode of a major scale               
            if is_in_list(msg, MODES_IN):
                #calls find in list to return the appropriate mode
                mode = find_in_list(msg, MODES_IN)
                #calls on find in list to return the appropriate music key
                tone = find_in_list(msg, MUSIC)   
                #calls on call_mode() to return a requested mode starting on inputed key
                scale = call_mode(tone,mode)
                #calls on list_to_string() to append a string to our output list
                scale = list_to_string(scale,' ')
                
                #calls on list_to_string() to append a mode as a strign and capitalizes it
                outs.append(list_to_string([mode.capitalize()],' '))
                #calls on list_to_string() to append a string to our output list
                outs.append('is ')
                #calls on list_to_string() to append a string of notes to our output list
                outs.append(list_to_string(scale, ' '))
                
                #turns outs the list into a string and sets it to be out_msg
                out_msg = (list_to_string(outs,' '))
                #bool to tell that out_msg has something in it and is not unknown
                idk = False
                
            # Catch-all to say something if msg not caught & processed so far
            if not out_msg:
                out_msg = list_to_string(UNKNOWN, ' ') 
                idk = True
        
        
        

        print('\nMusicBot:', out_msg)
        if chat and not idk:
            print( '\nAnother Scale?') 
            
            