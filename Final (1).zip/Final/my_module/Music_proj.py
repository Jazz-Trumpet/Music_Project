import string

class Music:



    def __init__(self, tone):
        
        self.tone = tone
        
    def Enharmonics(self):
    
        Flat_true = ['C','F','Bb','Eb','Ab','Db','Gb']
        is_flat = True
        if self.tone in Flat_true:
            is_flat = True
        if self.tone not in Flat_true:
            is_flat = False
        return is_flat
            
        

    def Sharps(self):
       
        """
        This function will take in a user inputed Tone,
        returning a list of 12 keys starting from that tone.
        This function will only return the sharp enharmonics
        """
        
        chrom = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B','C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
        #initialize output list
        Sharp_tones = [] 
        #boolean to determine if at the last
        End = False     
        
        
        for item in chrom:
           
            if len(Sharp_tones) == 12:
                    End = True
            if End == True:
                break
            #check if the first item is equal to the input Tone
            if item == self.tone: 
                Sharp_tones.append(self.tone)  
            if item != self.tone and len(Sharp_tones) > 0:
                Sharp_tones.append(item)
            
            
                  
        return Sharp_tones
    
    
    def Flats(self):
        
        """
        This function will take in a user inputed Tone,
        returning a list of 12 keys starting from that tone.
        This function will only return the flat enharmonics
        """
        chrom = ['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B','C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B']
        #initialize output list
        Flat_tones = [] 
        #boolean to determine if at the last
        End = False     
        
        
        for item in chrom:
           
            if len(Flat_tones) == 12:
                    End = True
            if End == True:
                break
            #check if the first item is equal to the input Tone
            if item == self.tone: 
                Flat_tones.append(self.tone)  
            if item != self.tone and len(Flat_tones) > 0:
                Flat_tones.append(item)
            
            
                  
        return Flat_tones
    
    
class Modes(Music):
    
    
    def __init__(self, tone, Chrom = []):
        super().__init__(tone)
        Input = Music(tone)
        is_flat = Input.Enharmonics()
        if is_flat == True:
            self.Chrom = Input.Flats()
        if is_flat == False:
            self.Chrom = Input.Sharps()
     
    
    
    def Ionian(self):
        
        Ionian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:6:2]:
                Ionian_mode.append(item)
            elif item in self.Chrom[5::2]:
                Ionian_mode.append(item)
        
        
        return Ionian_mode
    
    def Dorian(self):
        
        
        Dorian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:3:2]:
                Dorian_mode.append(item)
            elif item == self.Chrom[3]:
                Dorian_mode.append(item)
            elif item in self.Chrom[5:10:2]:
                Dorian_mode.append(item)
            elif item == self.Chrom[10]:
                Dorian_mode.append(item)
        
        return Dorian_mode
    


    def Phrygian(self):
        
        
        
        Phrygian_mode = []
        
        for item in self.Chrom:
            if item in self.Chrom[0:2:]:
                Phrygian_mode.append(item)
            elif item in self.Chrom[3:8:2]:
                Phrygian_mode.append(item)
            elif item in self.Chrom[8:11:2]:
                Phrygian_mode.append(item)
           
    
        return Phrygian_mode
    
    def Lydian(self):
        
        
        Lydian_mode = []
        
        for item in self.Chrom:
            if item in self.Chrom[0:7:2]:
                Lydian_mode.append(item)
            elif item in self.Chrom[7:12:2]:
                Lydian_mode.append(item)
            
                                     
        return Lydian_mode
    
    def Mixolydian(self):
        
        Mixolydian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:5:2]:
                Mixolydian_mode.append(item)
            elif item in self.Chrom[5:10:2]:
                Mixolydian_mode.append(item)
            elif item == self.Chrom[10]:
                Mixolydian_mode.append(item)
        
        return Mixolydian_mode
    
    
    def Aeolian(self):
        
        
        Aeolian_mode = []
        for item in self.Chrom:
            if item in self.Chrom[0:3:2]:
                Aeolian_mode.append(item)
            elif item == self.Chrom[3]:
                Aeolian_mode.append(item)
            elif item in self.Chrom[5:9:2]:
                Aeolian_mode.append(item)
            elif item in self.Chrom[8:11:2]:
                Aeolian_mode.append(item)
        
        return Aeolian_mode
    
    
    def Locrian(self):
        
        
        
        Locrian_mode = []
        
        for item in self.Chrom:
            if item in self.Chrom[0:2:]:
                Locrian_mode.append(item)
            elif item in self.Chrom[3:6:2]:
                Locrian_mode.append(item)
            elif item == self.Chrom[6]:
                Locrian_mode.append(item)
            elif item in self.Chrom[8:11:2]:
                Locrian_mode.append(item)
           
    
        return Locrian_mode
    

