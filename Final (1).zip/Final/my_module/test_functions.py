"""Test for my functions.

Note: because these are 'empty' functions (return None), here we just test
  that the functions execute, and return None, as expected.
"""

from functions import Music, Modes

##
##

def test_my_music():

    assert Music('C')

def test_my_mode():

    assert Modes('B')
